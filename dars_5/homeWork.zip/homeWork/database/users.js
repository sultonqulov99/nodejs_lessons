process.db.users = [
    {userId: 1, username: 'ali', age: 20, gender: 'male'},
    {userId: 2, username: 'halil', age: 19, gender: 'male'},
    {userId: 3, username: 'nigora', age: 15, gender: 'female'},
]