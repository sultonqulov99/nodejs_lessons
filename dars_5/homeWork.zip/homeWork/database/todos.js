process.db.todos = [
    {todoId: 1, userId: 1, completed: true, title: 'Uxlash kerak'},
    {todoId: 2, userId: 1, completed: false,title: 'Turish kerak'},
    {todoId: 3, userId: 2, completed: true, title: 'Dars qilish kerak'},
]